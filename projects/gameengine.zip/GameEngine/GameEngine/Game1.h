/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#include "Inneall.h"

class Game1 : public Game
{
public:
	virtual void initialise(Window& window);
	virtual void input(const Input& input, float delta);
};