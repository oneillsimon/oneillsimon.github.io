/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef INNEALL_H
#define INNEALL_H

#include "Engine\Cro�.h"
#include "Engine\Comhph�irteanna.h"
#include "Engine\Grafaic.h"
#include "Engine\Fisic.h"

#endif