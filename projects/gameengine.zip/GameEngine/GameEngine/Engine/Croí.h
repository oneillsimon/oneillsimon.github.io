/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef CRO�_H
#define CRO�_H

#include "Core\CoreEngine.h"
#include "Core\Game.h"
#include "Core\GameObject.h"
#include "Core\Input.h"
#include "Core\Math3D.h"
#include "Core\Profiling.h"
#include "Core\ReferenceCounter.h"
#include "Core\SDLWrapper.h"
#include "Core\Time.h"
#include "Core\Transform.h"
#include "Core\Util.h"

#include "Core\Scripter.h"

#endif