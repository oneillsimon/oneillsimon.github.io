/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef COMHPH�IRTEANNA
#define COMHPH�IRTEANNA

#include "Components\Game\Camera.h"
#include "Components\Game\FreeLook.h"
#include "Components\Game\FreeMove.h"
#include "Components\Game\Movement2D.h"

#include "Components\Rendering\Lighting.h"
#include "Components\Rendering\MeshRenderer.h"
#include "Components\Rendering\SpriteAnimator.h"
#include "Components\Rendering\SpriteRenderer.h"

#include "Components\Physics\ColliderRenderer.h"
#include "Components\Physics\PhysicsInput.h"

#endif