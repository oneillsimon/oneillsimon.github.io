/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef FISIC
#define FISIC

#include "Physics\Collider.h"
#include "Physics\Collision.h"
#include "Physics\Contacts.h"
#include "Physics\Octree.h"
#include "Physics\PhysicsComponent.h"
#include "Physics\PhysicsEngine.h"
#include "Physics\RigidBody.h"

#endif