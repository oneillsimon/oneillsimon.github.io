/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#include "PhysicsInput.h"

PhysicsInput::PhysicsInput(const PhysicsComponent& componet, int key1, int key2, int key3, int key4) :
	m_component(componet),
	m_key1(key1),
	m_key2(key2),
	m_key3(key3),
	m_key4(key4),
	m_simulate(false),
	m_start(false)
{
}

void PhysicsInput::input(const Input& input, float delta)
{
	if(input.getKey(m_key1) && !m_start)
	{
		m_component.getBody()->setAwake();
		m_component.getBody()->addForce(Vector3(0, -9.8f * m_component.getBody()->getMass(), 0));
	}

	if(input.getKey(m_key2))
	{
		m_simulate = true;
		fPass = false;
	}
}



void PhysicsInput::update(float delta)
{
	if(m_simulate)
	{
		m_component.getBody()->setAwake();
		fPass = true;
		m_component.getBody()->addForce(Vector3(0, -9.8f * m_component.getBody()->getMass(), 0));
	}
}