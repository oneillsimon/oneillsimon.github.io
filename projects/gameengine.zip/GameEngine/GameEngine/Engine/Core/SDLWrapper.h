/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef SDLWRAPPER_H
#define SDLWRAPPER_H

bool SDLGetIsCloseRequested();
void SDLSetIsCloseRequested(bool value);
void SDLCreateWindow(const char* title, int x, int y, int width, int height, bool fullScreen);
void SDLSetFullScreen(bool value);
void SDLSwapBuffers();
void SDLDestroyWindow();
void SDLSetMousePosition(int x, int y);

#endif