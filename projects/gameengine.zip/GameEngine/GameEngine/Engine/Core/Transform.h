/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef TRANSFORM_H
#define TRANSFORM_H

#include "Math3D.h"

class Transform
{
private:
	Transform* m_parent;
	mutable Matrix4 m_parentMatrix;

	Vector3 m_position;
	Quaternion m_rotation;
	Vector3 m_scale;

	mutable Vector3 oldPosition;
	mutable Quaternion oldRotation;
	mutable Vector3 oldScale;

	mutable bool m_intialisedOldStuff;

public:
	Transform(const Vector3& position = Vector3(), const Quaternion& rotation = Quaternion(0, 0, 0, 1), float scale = 1.0f);
	~Transform();

	bool hasChanged();
	void update();
	void rotate(const Vector3& axis, float angle);
	void rotate(const Quaternion& rotation);
	void lookAt(const Vector3& point, const Vector3& up);

	Quaternion getLookAtRotation(const Vector3& point, const Vector3& up);
	Matrix4 getTransformation() const;
	Vector3 getTransformedPosition() const;
	Vector3 getTransformedPoint(const Vector3& point) const;
	Quaternion getTransformedRotation() const;

	Transform* getParent();
	Matrix4 getParentMatrix() const;

	const Vector3& getPosition() const;
	Vector3& getPosition();
	const Quaternion& getRotation() const;
	Quaternion& getRotation();
	const Vector3& getScale() const;
	Vector3& getScale();

	void revertToPrevious();

	// TEMP
	Vector3 getPositionLua() const;
	void setScaleLua(const Vector3& v);
	Vector3 getScaleLua() const
	{
		return m_scale;
	}
	Vector3 getForward() const
	{
		return getRotation().getForward();
	}
	void rotateLua(const Vector3& v, float f);

	void setParent(Transform* parent);
	void setParentMatrix(Matrix4 parentMatrix);
	void setPosition(const Vector3& position);
	void setRotation(const Quaternion& rotation);
	void setScale(const Vector3& scale);
	void setScale(float scale);

	void operator =(const Transform& t);
	bool operator ==(const Transform& t);
	bool operator !=(const Transform& t);
};

#endif