/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef TIME_H
#define TIME_H

namespace Time
{
	double getTime();
};

#endif