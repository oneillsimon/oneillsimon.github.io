/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef GAME_H
#define GAME_H

#include "CoreEngine.h"

class Game
{
protected:
	GameObject rootObject;
	void addToScene(GameObject* object);

public:
	Game() {};
	virtual ~Game() {};

	virtual void initialise(Window& window);
	virtual void input(const Input& input, float delta);
	virtual void update(float delta);
	virtual void integrate(PhysicsEngine* physicsEngine, float delta);
	virtual void render(RenderingEngine* renderingEngine, const Camera& camera);

	GameObject& getRoot();

	void setEngine(CoreEngine* engine);
};

#endif