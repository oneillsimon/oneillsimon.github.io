/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef SCRIPTMANAGER_H
#define SCRIPTMANAGER_H

#include <fstream>
#include <stdio.h>
#include <string>
#include <vector>

#include "Input.h"
#include "GameComponent.h"
#include "Lua.h"
#include "../Rendering/RenderingEngine.h"

enum FUNC_TYPE
{
	INIT,
	INPUT,
	UPDATE,
	RENDER,
	OTHER
};

class Scripter : public GameComponent
{
private:
	lua_State* m_L;
	std::string m_scriptName;
	std::ofstream m_finalScript;

	std::vector<std::string> m_otherCode;
	std::vector<std::string> m_localCode;
	std::vector<std::string> m_initCode;
	std::vector<std::string> m_inputCode;
	std::vector<std::string> m_updateCode;
	std::vector<std::string> m_renderCode;

	void loadScript(const std::string& fileName);

	void addFunctionCode(const std::string& code, int function);
	void addLocalCode(const std::string& code);

	void generateFunctionBody(std::ifstream& file, int function, const std::string& functionDeclartion = "");

public:
	Scripter(std::initializer_list<std::string> scripts = {});
	~Scripter();

	virtual void initialise();
	virtual void input(const Input& input, float delta);
	virtual void update(float delta);
	virtual void render(const Shader& shader, const RenderingEngine& renderingEngine, const Camera& camera) const;

	void addScript(const std::string& script);


	template<class T>
	void setGlobal(const std::string& name, T t)
	{
		luabridge::setGlobal(m_L, t, name.c_str());
	}

	void generateScriptName(void* object);

	lua_State* getL();

	std::string getScriptName() const;

	void setFunctionCode(const std::string& code, int index, int function);
	void setLocalCode(const std::string& code, int index);

	std::vector<std::string> getFunctionCode(int function) const;
	std::vector<std::string> getLocalCode() const;
};

#endif