/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef GAMEENGINE_H
#define GAMEENGINE_H

#include "Comhph�irteanna.h"
#include "Cro�.h"
#include "Grafaic.h"

#endif