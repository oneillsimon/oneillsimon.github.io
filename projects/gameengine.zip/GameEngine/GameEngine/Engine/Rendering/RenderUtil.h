/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#ifndef RENDERUTIL_H
#define RENDERUTIL_H

class RenderUtil
{
public:
	static void clearScreen();
	static void initGraphics();
};

#endif