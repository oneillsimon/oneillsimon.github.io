/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#include "Game1.h"

#include <iostream>
#include <math.h>

#undef main

int main()
{
	Game1 game1;
	CoreEngine engine(800, 600, 120, &game1);
	engine.createWindow("Game ENGINE");
	engine.start();

	return 0;
}