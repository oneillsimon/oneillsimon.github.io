/*
Simon O'Neill
Sol Game Engine

Final Year Project Submission
*/

#include "Game1.h"

void Game1::initialise(Window& window)
{
	GameObject* cameraObj = new GameObject(Vector3(0, 5, -7.5f));

	cameraObj->addComponent(new FreeLook(window.getCentre()));
	cameraObj->addComponent(new FreeMove());
	cameraObj->addComponent(new CameraComponent(Matrix4().initPerspective(toRadians(70.0f), window.getAspectRatio(), 0.1f, 1000.0f)));
	PhysicsComponent* camComp = new PhysicsComponent(new ColliderSphere(1), new RigidBody(INT_MAX));
	camComp->getBody()->setCanSleep(false);
	camComp->getBody()->setAwake(true);
	cameraObj->addComponent(camComp);

	addToScene(cameraObj);

	Vector3 v(255, 255, 0);

	GameObject* lightObj = new GameObject(Vector3(0, -20, 0));
	lightObj->getTransform()->rotate(AXIS_XZ, toRadians(-60));
	lightObj->addComponent(new DirectionalLight(COLOUR_WHITE, 0.4f));
	Scripter* s__ = new Scripter();
	s__->addScript("rotate.lua");
	addToScene(lightObj);

	GameObject* lightObj2 = new GameObject(Vector3(0, -20, 0));

	lightObj2->getTransform()->rotate(AXIS_XZ, toRadians(-60));
	lightObj2->getTransform()->rotate(AXIS_Y, toRadians(180));
	lightObj2->addComponent(new DirectionalLight(COLOUR_CORAL, 0.4f));
	addToScene(lightObj2);

	for(int i = 0; i < 4; i++)
	{
		Vector3 v;
		float angle = 0;
		float y = -4.0f;
		float d = 8.5f;

		switch(i)
		{
		case 0:
			v = Vector3(0, y, d);
			angle = 180;
			break;
		case 1:
			v = Vector3(0, y, -d);
			angle = 0;
			break;
		case 2:
			v = Vector3(d, y, 0);
			angle = 90;
			break;
		case 3:
			v = Vector3(-d, y, 0);
			angle = -90;
			break;
		}

		GameObject* obj = new GameObject(v);
		obj->getTransform()->rotate(AXIS_Y, toRadians(-angle));
		obj->addComponent(new SpotLight(COLOUR_BLUE, 2.4, Attenuation(), 45));
		addToScene(obj);
	}

	int s = 10;
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			Material mat = Material("mat", Texture(""), getRandomColour());

			switch(j)
			{
			case 0:
				v = Vector3(0, s, 2.5f);
				break;
			case 1:
				v = Vector3(0, s, -2.5f);
				break;
			case 2:
				v = Vector3(2.5f, s, 0);
				break;
			case 3:
				v = Vector3(-2.5f, s, 0);
				break;
			}

			int r = random(10, 15);
			r /= 10.0f;
			PhysicsComponent* physicsComponent = new PhysicsComponent(new ColliderSphere(r), new RigidBody(1));
			physicsComponent->getBody()->setCanSleep(true);
			physicsComponent->getBody()->setRestitution(1.0f);
			physicsComponent->getBody()->setFriction(0.95f);
			float c = random(-10, 10);
			v = v + (c / 10.0f);
			GameObject* cubeoObj = new GameObject(v, Quaternion(), r);

			cubeoObj->addComponent(new MeshRenderer(Mesh("sphere.obj"), mat));
			cubeoObj->addComponent(physicsComponent);
			cubeoObj->addComponent(new PhysicsInput(*physicsComponent, Input::KEY_1, Input::KEY_2));
			addToScene(cubeoObj);
		}

		s += 5;
	}

	PhysicsComponent* planeComponent = new PhysicsComponent(new ColliderPlane(Vector3(0, 1, 0), -5), 0);

	GameObject* planeObj = new GameObject(Vector3(0, -5, 0));
	planeObj->getTransform()->setScale(100);
	planeObj->addComponent(planeComponent);
	planeObj->addComponent(new MeshRenderer(Mesh("plane.obj"), Material("", TEXTURE_BLANK, COLOUR_HOT_PINK, 0.01f)));

	addToScene(planeObj);

	GameObject* monkey = new GameObject(Vector3(10, 4, 10));
	Scripter* scripter = new Scripter();
	scripter->addScript("move.lua");
	scripter->addScript("scale.lua");
	monkey->addComponent(scripter);
	monkey->addComponent(new MeshRenderer(Mesh("monkey3.obj"), Material("", TEXTURE_BLANK, getRandomColour())));
	addToScene(monkey);

	GameObject* monChild = new GameObject(Vector3(0, 0, -2), Quaternion(AXIS_Y, toRadians(180)), 0.5f);
	monChild->addComponent(new MeshRenderer(Mesh("monkey3.obj"), Material("", TEXTURE_BLANK, getRandomColour())));
	monkey->addChild(monChild);

	GameObject* normalMap = new GameObject(Vector3(-10, 3, 2));
	normalMap->getTransform()->setScale(2.0f);
	Texture t = Texture("bricks2.jpg");
	Texture tn = Texture("bricks2_normal.jpg");
	SpriteSheet ss = SpriteSheet("sprite", Material("bricks", t, COLOUR_WHITE, 1, 8, tn), 1, 1);
	normalMap->addComponent(new SpriteRenderer(ss));
	normalMap->getTransform()->rotate(AXIS_X, toRadians(180));
	normalMap->getTransform()->rotate(AXIS_Y, toRadians(180));
	addToScene(normalMap);

	GameObject* dispMap = new GameObject(Vector3(-14, 3, 2));
	dispMap->getTransform()->setScale(2.0f);
	Texture t_ = Texture("bricks.jpg");
	SpriteSheet ss_ = SpriteSheet("sprite", Material("bricks", t_, COLOUR_WHITE, 1, 8, Texture("bricks_normal.jpg"), Texture("bricks_disp.png"), 0.04f, -0.0f), 1, 1);
	dispMap->addComponent(new SpriteRenderer(ss_));
	dispMap->getTransform()->rotate(AXIS_X, toRadians(180));
	dispMap->getTransform()->rotate(AXIS_Y, toRadians(180));
	addToScene(dispMap);

	GameObject* spriteObj = new GameObject(Vector3(10, 3, 0));
	SpriteSheet sprite = SpriteSheet("sprite2", Material("bricks", Texture("braid-dinosingle.png")), 12, 1);
	spriteObj->addComponent(new SpriteRenderer(sprite));
	spriteObj->addComponent(new SpriteAnimator(sprite, 100.0f));
	spriteObj->getTransform()->rotate(AXIS_X, toRadians(180));
	addToScene(spriteObj);

	window.setFullScreen(false);

	Game::initialise(window);
}

void Game1::input(const Input& input, float delta)
{
	if(input.getKey(Input::KEY_Q))
	{
		Game::getRoot().getEngine()->stop();
	}

	Game::input(input, delta);
}