function scale(a)
	v = transform:getScale()
	v:setX(v:getX() + a)
	v:setY(v:getY() + a)
	v:setZ(v:getZ() + a)
	transform:setScale(v)
end

function input(delta)
	if(input:getKey(KEY_PAGEUP)) then
		scale(0.01)
	end

	if(input:getKey(KEY_PAGEDOWN)) then
		scale(-0.01)
	end
end