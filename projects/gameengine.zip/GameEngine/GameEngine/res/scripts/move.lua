function move(dir, amount)
	v = transform:getPosition()
	v:setX(v:getX() + (amount * dir:getX()))
	v:setY(v:getY() + (amount * dir:getY()))
	v:setZ(v:getZ() + (amount * dir:getZ()))
	transform:setPosition(v)
end

function rotate(a)
	transform:rotate(Math.Vector3(0, 1, 0), (a * 3.14 / 180.0))
end

local movSpeed = 15;
local rotSpeed = 180;

function input(delta)
	if input:getKey(KEY_UP) then
		move(transform:getForward(), movSpeed * delta)
	end
	
	if input:getKey(KEY_DOWN) then
		move(transform:getForward(), -movSpeed * delta)
	end
	
	if input:getKey(KEY_LEFT) then
		rotate(-rotSpeed * delta)
	end
	
	if input:getKey(KEY_RIGHT) then
		rotate(rotSpeed * delta)
	end
end