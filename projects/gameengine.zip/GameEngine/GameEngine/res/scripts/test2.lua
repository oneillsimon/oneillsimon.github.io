
local t_ = transform
local pos = 0

function update(delta)
	pos = 10 + pos
end